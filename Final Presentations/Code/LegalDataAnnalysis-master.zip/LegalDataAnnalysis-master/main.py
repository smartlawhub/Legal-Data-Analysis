import requests
import json
import csv
import re

from bs4 import BeautifulSoup
from os import walk

exportPath = "output/"
websiteUrl = "https://www.courdecassation.fr/"

def scrapDecision(url):
    print("Get : " + url)
    response = requests.get(url)

    if response.status_code == 200:
        soup = BeautifulSoup(response.content, "html.parser")

        decisionContent = [section for section in soup.find_all("p", class_="decision-accordeon--contenu")]
       
        data = {}
        if decisionContent:
            for content in decisionContent:
                lines = [line.strip() for line in "".join(content.strings).splitlines()]
                data[content.get("id")] = [line.strip() for line in lines if line != '']
        else: 
            decisionContent = [section for section in soup.find(class_="decision-element--texte-decision")]
            for content in decisionContent:
                if content.name == "p":
                    lines = [line.strip() for line in "".join(content.strings).splitlines()]
                    data["decision-0"] =  [line.strip() for line in lines if line != '']
        
        name = url.split("/")[-1]
        exportTojson(exportPath + name + ".json", data)

    else:
        print("Erreur lors de la requête: code de statut", response.status_code)

def scrapPage(url):
    print("Get : " + url)
    response = requests.get(url)

    if response.status_code == 200:
        soup = BeautifulSoup(response.content, "html.parser")

        decisionLinks = [paragraph.find("a").get("href") for paragraph in soup.find_all("p", class_="lien-voir")]

        for link in decisionLinks:
            scrapDecision(websiteUrl + link)


        nextPageButton = soup.find("li", class_="pager__item--next")
        if nextPageButton == None:
            print("Scrap every page")
            return
        
        nextPageLink = nextPageButton.find("a").get("href")

        scrapPage(websiteUrl + nextPageLink)

    else:
        print("Erreur lors de la requête: code de statut", response.status_code)

def exportTojson(path, data): 
    print("Export : " + path)
    jsonStr = json.dumps(data, indent=4)

    with open(path, "w") as text_file:
        text_file.write(jsonStr)

def scrap():
    scrapPage("https://www.courdecassation.fr//recherche-judilibre?date_au=&date_du=&judilibre_juridiction=cc&op=Rechercher%20sur%20judilibre&search_api_fulltext=Code%20de%20l%27entr%C3%A9e%20et%20du%20s%C3%A9jour%20des%20%C3%A9trangers%20et%20du%20droit%20d%27asile&page=84")

def scrapMissingDecision():
    for (dirpath, dirnames, filenames) in walk(exportPath):
        for filename in filenames:
            filePath = dirpath + filename

            with open(filePath, "r") as decisionFile:
                decisions = json.loads(decisionFile.read())

                if not decisions:
                    scrapDecision(websiteUrl + "decision/" + filename.split(".")[0])

def extractPresident(json):
    patterns = [ r'(le premier président)', r'(M .*),', r'(M\. .*) président', r'(Mme .*),'] 

    for line in json:
        if "président" in line.lower() :
            for pattern in patterns:
                search = re.search(pattern, line)
                if search and search.group(1):
                    president = search.group(1)
                    president.replace(',', '')
                    return president
    return ""
        
def extractDecision(json):
    exactPatternsBefore = ['casse et annule, dans toutes', 'casse et annule, en toutes']

    patterns = ['cassation sans renvoi', 'rejet non spécialement motivé', 'annulation partielle', 'cassation partielle', 'rejette le pourvoi', 
          'non-lieu a renvoi', 'cassation partielle sans renvoi', 'casse et annule']

    exactPatterns = ['cassation', 'rejet', 'annulation']

    for line in json:
        lower = line.lower()
        for pattern in exactPatternsBefore:
            if pattern in lower: 
                return pattern
        for pattern in patterns:
            if pattern in lower:
                return lower
        for pattern in exactPatterns:
            if exactPatterns == lower: 
                return lower
    return ""
            
def extractFormation(json):
    patterns = ["chambre criminelle", "première chambre civile", "deuxième chambre civile", "chambre sociale"]

    for line in json:
        lower = line.lower()
        for pattern in patterns:
            if pattern in lower:
                return pattern
    return ""
            
def extractApplicant(json):
    patterns = ['formé le pourvoi', 'formé des pourvois', 'le pourvoi formé par', 'pourvoi par lui formé']

    result = ""
    for line in json:
        lower = line.lower()

        if result and lower.split(" ")[0] == "contre":
            return result + " " + lower
        elif result:
            return result

        for pattern in patterns:
            if pattern in lower:
                result = lower
                break
    return result

def extractDispute(json):
    patterns = ["code de l'entrée et du séjour des étrangers et du droit d'asile", "CESEDA"]
    articlePatterns = [r"l[\.]* [0-9]+-[0-9]+", r"r[\.]* [0-9]+-[0-9]+"]

    for line in json:
        lower = line.lower()
        for pattern in patterns:
            if pattern in lower:
                article = []
                for articlePattern in articlePatterns:
                    article += re.findall(articlePattern, lower)

                return article
    return ""

def extractFields(function, decisions):
    for key, value in decisions.items():
        data = function(value)
        if data:
            return data.replace(";", "").strip()
    return ""


def readAndExtract(path):
    data = {
        "president": "",
        "decision": "",
        "formation": "",
        "applicant": "",
        "dispute": "",
    }

    with open(path, "r") as decisionFile:
        decisions = json.loads(decisionFile.read())
        
        data["president"] = extractFields(extractPresident, decisions) 
        data["decision"] =  extractFields(extractDecision, decisions)
        data["formation"] =  extractFields(extractFormation, decisions)
        data["applicant"] =  extractFields(extractApplicant, decisions)

        articles = []
        for key, value in decisions.items():
            articles += extractDispute(value)
        data["dispute"] = " / ".join(set(articles))
    return data

def convertToCsv(input, output):
    with open(output, 'w', newline='') as csvfile:
        fieldnames = ["president","decision","formation","applicant","dispute"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames, delimiter=';')
        writer.writeheader()

        for (dirpath, dirnames, filenames) in walk(input):
            for filename in filenames:
                filePath = dirpath + "/" + filename
                data = readAndExtract(filePath)
                writer.writerow(data)
                print("filename : " + filename + " " + str(data))

def main():
    convertToCsv("output", "output.csv")
    # scrap()
    # scrapMissingDecision()

if __name__ == "__main__":
    main()