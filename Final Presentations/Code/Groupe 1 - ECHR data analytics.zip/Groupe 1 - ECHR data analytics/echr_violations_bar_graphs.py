import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# This section is only relevant to the violations per country 



df = pd.read_csv('echr_clean_data.csv')

# We set the color palette, font size and style
plt.rcParams['axes.prop_cycle'] = plt.cycler(color=plt.cm.viridis(np.linspace(0, 1, 10)))
plt.rcParams.update({'font.size': 12})
plt.rcParams['font.family'] = 'serif'

# We create a bar chart that shows the 10 states with the most violations

df = df.sort_values(by=['Violations'], ascending=False)
df = df.head(10)
df.plot.bar(x='State', y='Violations', color='purple')

plt.legend().set_visible(False)
plt.xticks(fontsize=8)
plt.title('The 10 States with the most ECHR violations')
plt.grid(True)
plt.savefig('echr_violations_static.png', dpi=300, bbox_inches='tight')







# This section is relevant to the violations per article



df = pd.read_csv('echr_articles_violated.csv')

# We iterate over each row and of df and add every unique article violated to a dictionary with its count as value
articles_violated = {}
for i, row in df.iterrows():
    for j, article in enumerate(row):
        if j > 4:
            if article in articles_violated:
                articles_violated[article] += 1
            else:
                articles_violated[article] = 1

# we create a new dataframe with the articles and their counts
new_df = pd.DataFrame(columns=['Article', 'Count'])
for article in articles_violated:
    new_df = new_df.append({'Article': article, 'Count': articles_violated[article]}, ignore_index=True)

# we sort the dataframe by the count and remove nan values
new_df = new_df.sort_values(by=['Count'], ascending=False)
new_df = new_df.dropna()

# we create a bar chart with the 10 most violated articles and display it
# Truncate the x-axis labels to 10 characters
plt.rcParams['axes.prop_cycle'] = plt.cycler(color=plt.cm.viridis(np.linspace(0, 1, 10)))
new_df = new_df.head(10)
new_df.plot.bar(x='Article', y='Count', color='purple')

plt.legend().set_visible(False)
plt.xticks(fontsize=8)
plt.title('The 10 most frequent ECHR Articles violations')
plt.grid(True)
plt.savefig('echr_articles_violated_static.png', dpi=300, bbox_inches='tight')


