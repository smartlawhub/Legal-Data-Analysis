import pandas as pd
import numpy as np

# We read the original CSV file into a pandas dataframe
df = pd.read_csv('EchrBaseFull.csv')

# We delete any trailing whitespace in the State column values
df['State'] = df['State'].str.strip()

# We manually replace any incorrect state names with the correct name for cases that were too damaging to be ignored

df['State'] = df['State'].replace('THE REPUBLIC OF MOLDOVA', 'MOLDOVA')
df['State'] = df['State'].replace('TÜRKIYE', 'TURKEY')
df['State'] = df['State'].replace('TÜRKİYE', 'TURKEY')
df['State'] = df['State'].replace('TURQUIE', 'TURKEY')
df['State'] = df['State'].replace('LUXEMBURG', 'LUXEMBOURG')
df['State'] = df['State'].replace('ITALIE', 'ITALY')


# We create a csv speciically for quick looks at violations per state

# We find unique states, and count the number of violations and non violations for each one
state_counts = df.groupby('State').size().reset_index(name='Total_mentions')
violations = df[df['Articles violated'] != '[]'].groupby('State').size().reset_index(name='Violations').astype({'Violations': 'Int64'})
non_violations = df[df['Articles not violated'] != '[]'].groupby('State').size().reset_index(name='Non-violations').astype({'Non-violations': 'Int64'})
result = pd.merge(state_counts, violations, on='State', how='left').merge(non_violations, on='State', how='left').fillna(0)

# We filter out any States that have less than 10 mentions and sort the dataframe by the number of violations

result = result.sort_values(by=['Violations'], ascending=False)
result = result[result['Total_mentions'] > 9]

# We write to a new CSV file
result.to_csv('echr_clean_data.csv', index=False)



# We create a csv speciically for charts related to the number of articles violated

# determine the maximum number of elements in the 'Articles violated' column
max_articles_violated = max(df['Articles violated'].str.split(',').apply(len))
new_cols = ['Article ' + str(i+1) for i in range(max_articles_violated)]
new_df = pd.DataFrame(columns=['Nb', 'Ids', 'State', 'Date', 'Conclusions'] + new_cols)

# iterate over each row in the original dataframe
for i, row in df.iterrows():
    articles_violated = row['Articles violated'].strip('][').split(', ')
    new_row = {
        'Nb': row['Nb'],
        'Ids': row['Ids'],
        'State': row['State'],
        'Date': row['Date'],
        'Conclusions': row['Conclusions']
    }
    for j, article in enumerate(articles_violated):
        new_row[new_cols[j]] = article
    
    # append the new row to the new dataframe
    new_df = new_df.append(new_row, ignore_index=True)

# we replace any cell which contains "Article 1 of Protocol No. 1" with "P1-Article1"
new_df = new_df.replace(to_replace='Article 1 of Protocol No. 1', value='P1-Article1')

# output the new dataframe to a CSV file
new_df.to_csv('echr_articles_violated.csv', index=False)