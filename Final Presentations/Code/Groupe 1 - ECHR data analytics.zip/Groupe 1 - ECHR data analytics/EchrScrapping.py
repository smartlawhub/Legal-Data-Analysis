import pandas as pd
import re
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
import time

# Main page of Hudoc
html_echr = "https://hudoc.echr.coe.int/eng#{%22documentcollectionid2%22:[%22JUDGMENTS%22]}"
# Set of languages to process
LANGUAGES_TO_PROCESS = ["english", "french", "not english french"]
# define the name of the output file
FILENAME = "EchrBaseFull"

# To build the list of cases
data_scrapped = []
caseids_list = []

# First step: get the cases filtered by language
for languageToProcess in LANGUAGES_TO_PROCESS:
    # Open the dataBase in Chrome with Selenium
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.get(html_echr)
    time.sleep(2)

    # Retrieve the more button in FILTERS/LANGUAGE section
    button = driver.find_element(By.XPATH, "//*[@id='refinement-filters-row1-left']")
    button = button.find_element(By.XPATH, ".//button[@class='morebutton']")
    # Scroll until the button is in the view to be able to click on it
    button.location_once_scrolled_into_view
    button.click()
    time.sleep(2)

    languages = languageToProcess.split()
    for language in languages:
        if language.lower() == "not":
            # We want to ignore the given languages
            button = driver.find_element(By.XPATH, "//*[@id='radio_choices_NOT']")
            button.click()
        elif language.lower() == "english":
            # Click on the given language
            button = driver.find_element(By.XPATH, "//*[@id='ENG']/h4")
            button.location_once_scrolled_into_view
            button.click()
        elif language.lower() == "french":
            button = driver.find_element(By.XPATH, "//*[@id='FRE']/h4")
            button.location_once_scrolled_into_view
            button.click()

    # Click on OK
    button = driver.find_element(By.XPATH, "//*[@id='okbutton']")
    button.click()
    time.sleep(2)

    # Second step: get the page to scroll down
    soup = BeautifulSoup(driver.page_source, features="html.parser")
    nb_cases_to_get = int(soup.find("span", class_="resultNumber").contents[0])
    print("Number of cases to process: " + str(nb_cases_to_get))

    nb_cases_per_scroll = len(soup.find("div", class_="results-list-block").findChildren("div", title="Results"))
    for x in range(int(nb_cases_to_get/nb_cases_per_scroll)+10):  # add a small margin
        driver.find_element(By.CSS_SELECTOR, "body").send_keys(Keys.CONTROL, Keys.END)
        time.sleep(0.5)
    soup = BeautifulSoup(driver.page_source, features="html.parser")
    list_of_cases = soup.find("div", class_="results-list-block").findChildren("div", title="Results")
    print("Number of cases processed: " + str(len(list_of_cases)))

    # Third step: extract the relevant information from each case
    for case in list_of_cases:
        try:
            # Get caseId to check if the same case has already been processed
            linetwo = case.find("div", class_="linetwo")
            caseid = linetwo.find("span", class_="column summaryblock").find("span", class_="fulltext").find('span', class_="textColumn").get_text()
            if caseid in caseids_list:
                continue  # Skip this entry, case already processed

            # The State(s) are on lineone
            lineone = case.find("div", class_="lineone")
            states = lineone.find("a", class_="document-link headline").get_text()
            x = re.search(r" [vc]\. ", states)
            states = re.findall(r"[\w\s]+", states[x.end():])

            # The Date is on linetwo
            date = linetwo.find("span", class_="column dateColumn").get_text()

            # The conclusion(s) are on linethree
            linethree = case.find("div", class_="linethree")
            conclusions = linethree.find("span", class_="summaryblock").find("span", class_="fulltext").get_text(strip=True)
            articles = re.sub("No violation Of |Non-violation de l'", "ViolationNot", conclusions, 0, re.I)
            articles = re.sub("violation Of |violation de l'", "Violation", articles, 0, re.I)
            articles = re.sub("art\.", "Article", articles, 0, re.I)
            articles_not_violated = re.findall("(?<=ViolationNot)Article \d+ du Protocole n°\s?\d+|(?<=ViolationNot)Article \d+ of Protocol No.\s?\d+|(?<=ViolationNot)Article [P?\d+-?\d*\+?]+", articles, re.I)
            articles_violated = re.findall("(?<=Violation)Article \d+ du Protocole n°\s?\d+|(?<=Violation)Article \d+ of Protocol No.\s?\d+|(?<=Violation)Article [P?\d+-?\d*\+?]+", articles, re.I)
            case_elements = [caseid, states[0], date, conclusions, list(set(articles_violated)), list(set(articles_not_violated))]

            data_scrapped.append(case_elements)
            caseids_list.append(caseid)
        except:
            continue
    driver.close()

# Fourth step: prepare the dataframe with the list built from each case
df = pd.DataFrame(data_scrapped, columns=["Ids", "State", "Date", "Conclusions", "Articles violated", "Articles not violated"])
df.to_csv(FILENAME + ".csv", encoding="utf8")
df.to_excel(FILENAME + ".xlsx")