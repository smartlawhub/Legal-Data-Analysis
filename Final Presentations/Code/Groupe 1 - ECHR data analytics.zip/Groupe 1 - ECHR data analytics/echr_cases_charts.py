import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Read the original CSV file into a pandas dataframe
df = pd.read_csv('EchrBaseFull.csv')

# convert the column 'Date' to a datetime object
df['Date'] = pd.to_datetime(df['Date'])

# We set the color palette, font size and style
plt.rcParams['axes.prop_cycle'] = plt.cycler(color=plt.cm.viridis(np.linspace(0, 1, 10)))
plt.rcParams.update({'font.size': 12})
plt.rcParams['font.family'] = 'serif'

# We plot the data for each year and exclude 2023 as the year isn't over yet and export to png

df.groupby(df['Date'].dt.year).count()['State'].plot.line(color='purple', marker='o', markersize=5, linewidth=2)
plt.title('Number of ECHR decisions per year')
plt.grid(True)
plt.xlim(1959, 2022)
plt.savefig('echr_yearlycases.png', dpi=300, bbox_inches='tight')

# we reset the plot / figure
plt.clf()

# We plot the cumulative number of cases over time and export to png

df.groupby(df['Date'].dt.year).count()['State'].cumsum().plot.line(color='purple', marker='o', markersize=5, linewidth=2)
plt.title('Cumulative number of ECHR decisions')
plt.grid(True)
plt.savefig('echr_totalcases.png', dpi=300, bbox_inches='tight')

# determine the maximum number of elements in the 'Articles violated' column
max_articles_violated = max(df['Articles violated'].str.split(',').apply(len))

# create a list of new column names for each article violated
new_cols = ['Article ' + str(i+1) for i in range(max_articles_violated)]

# create a new dataframe with the appropriate columns
new_df = pd.DataFrame(columns=['Nb', 'Ids', 'State', 'Date', 'Conclusions'] + new_cols)

# iterate over each row in the original dataframe
for i, row in df.iterrows():
    # split the 'Articles violated' column into a list of strings
    articles_violated = row['Articles violated'].strip('][').split(', ')
    
    # create a new row in the new dataframe with the appropriate data
    new_row = {
        'Nb': row['Nb'],
        'Ids': row['Ids'],
        'State': row['State'],
        'Date': row['Date'],
        'Conclusions': row['Conclusions']
    }
    for j, article in enumerate(articles_violated):
        new_row[new_cols[j]] = article
    
    # append the new row to the new dataframe
    new_df = new_df.append(new_row, ignore_index=True)

# output the new dataframe to a CSV file
new_df.to_csv('echr_articles_violated.csv', index=False)

