import argparse
import requests
import json

def fetch_conseil_etat_data(start_date, end_date, match, code_filter):
    url = 'https://www.conseil-etat.fr/xsearch?type=json'
    headers = {'authority': 'www.conseil-etat.fr','accept': 'application/json, text/plain, */*','accept-language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7','content-type': 'application/x-www-form-urlencoded','dnt': '1','referer': 'https://www.conseil-etat.fr/arianeweb/','sec-ch-ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"','sec-ch-ua-mobile': '?0','sec-ch-ua-platform': '"Linux"','sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-origin','user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'}
    data = {'advanced': '1','type': 'json','SourceStr4': code_filter,'text.add': '','synonyms': 'true','scmode': 'smart','aftersourcedatetime1': start_date,'beforesourcedatetime1': end_date,'SkipCount': '1000','SkipFrom': '0','sort': 'SourceDateTime1.desc,SourceStr5.desc'}
    total_count, data["SkipFrom"] = 0, 0
    processed_data = {"documents": [], "total_match": 0, "stats": {}}
    while True:
        response = requests.post(url, headers=headers, data=data)
        json_data = response.json()
        total_count = int(json_data["TotalCount"])
        data["SkipFrom"] += 1000
        n_url = "https://www.conseil-etat.fr/plugin?plugin=Service.callXdownloadAW&action=Search"
        n_header = {'accept': 'application/json, text/plain, */*','accept-language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7','content-type': 'application/json;charset=UTF-8','cookie': '_pk_id.28.2862=a97b414ac535b546.1710860895.; accept_cookies=!vimeo=false!youtube=false; vrn=6; _pk_ref.28.2862=["","",''1711199709,"https://messages.google.com/"]; _pk_ses.28.2862=1; ASP.NET_SessionId=vqjqxkbidp4fmfr53pvavq55','dnt': '1','origin': 'https://www.conseil-etat.fr','referer': 'https://www.conseil-etat.fr/arianeweb/','sec-ch-ua': '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"','sec-ch-ua-mobile': '?0','sec-ch-ua-platform': '"Linux"','sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-origin','user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36'}
        for d in json_data["Documents"]:
            body = '{"documentId": "' + d["Id"][12:] +'"}'
            resp = requests.post(n_url, headers=n_header, data=body)
            if match.lower() in resp.text.lower():
                print("Match found document id: {0} for match: {1}".format(d["Id"][12:], match))
                processed_data["documents"].append(d)
                if d["SourceInt1"] not in processed_data["stats"]:
                    processed_data["stats"][d["SourceInt1"]] = 0 
                processed_data["stats"][d["SourceInt1"]] += 1
        if len(processed_data["documents"]) >= total_count or data["SkipFrom"] > total_count:
            break
        print(f"Fetched {data['SkipFrom']} out of {total_count} documents")

    processed_data["total_match"] = len(processed_data["documents"])
    with open(f"conseiletat-{code_filter}.json", 'w') as f:
        json.dump(processed_data, f)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Fetch Conseil d\'Etat data")
    parser.add_argument('--start', type=str, help="Start date for the search", default="2000-01-01", nargs="?")
    parser.add_argument('--end', type=str, help="End date for the search", default="2024-03-31", nargs="?")
    parser.add_argument('--match', type=str, help="Match string to search", default="L. 16 B", nargs="?")
    parser.add_argument("--code", type=str, help="Code filter for ariane web database", default="AW_DCE", nargs="?")
    args = parser.parse_args()
    fetch_conseil_etat_data(args.start, args.end, args.match, args.code)


# AW_DCE = DECISION DU CONSEIL D'ETAT
# AW_AJCE = Analyses du Conseil d'État
# AW_CRP = Conclusions des rapporteurs publics
# AW_DTC = Décisions du Tribunal des conflits
# AW_AJTC = Analyses du Tribunal des conflits
# AW_DCA = Arrêts des cours administratives d'appel
# AW_AJCA = Analyses des cours administratives d'appel
